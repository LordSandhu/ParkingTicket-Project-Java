package SoftwareCode;

public abstract class Person {
 public String F_name;
 public String L_name;
 public String Email;
 public String Pasword;
 public Boolean L_status;
 public abstract void  Set_name(String F_name,String L_name);
 public abstract void  Set_acc(String Email,String Password);
 
 
 }
