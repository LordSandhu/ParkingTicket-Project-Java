package SoftwareCode;

public class t {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
 	  menu x=new menu();
 	  x.Start();
 	  
	}

}
